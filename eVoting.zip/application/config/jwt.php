<?php defined('BASEPATH') or exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| JWT Secure Key
|--------------------------------------------------------------------------
*/
$config['jwt_key'] = "-ZSBUXQCx1ZpXX_28ICSM5ckPgLq_C-ZsgdMrb75VWOK8_TNKlmpFUgih4JOr0dk0HXdMhQgSRjzL3Di-8HNpl6amv9Pg9EuhobVqLuDkPvTHXB2QSkWM3ohhucQYAd-1FG6bwFtGS4-4-cXZahcJXq0Wpx-Ywf3X0iNNPd4z4FjKSmKSUAfbrb6N6eA-CUHiN1D_dy93XisZOf5dXQUmKeWfaKvZ8EMw8CKfAFyTONrZCaoRVqd664NASqE1b4XldgSC9J-6R7Jq06nBNRAwdAB6wRhfjVVc_qiMmu9ywl5KSzuYgSfoxyBOxtIjn6YuvFeY5ft75k8hzJ6PKDudA";



/*
|--------------------------------------------------------------------------
| JWT Algorithm Type
|--------------------------------------------------------------------------
*/
$config['jwt_algorithm'] = 'HS256';
